﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputTesting : MonoBehaviour {
    public spawner spawnerscript;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(Input.GetKeyDown("space"))
        {spawnerscript.SpawnObject(this.transform.position);
          
        }
	}
}
