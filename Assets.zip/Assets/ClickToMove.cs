﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClickToMove : MonoBehaviour {
    public Camera cam;
    public GameObject player;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 screenPosition = Vector3.zero;
        if(Input.GetMouseButtonDown(0)){
            Debug.Log("mouse button is clicked");
            Debug.Log(screenPosition);

            screenPosition.x= Input.mousePosition.x;
            screenPosition.y= Input.mousePosition.y;
            screenPosition.z = -cam.transform.position.z;
           // Debug.Log(Camera.main.ScreenToWorldPoint(Input.mousePosition));

            player.transform.position = cam.ScreenToWorldPoint(screenPosition);
        }
	}
}
