﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {
    public float movementSpeed = 1f;
    Vector3 newPosition = Vector3.zero;
	// Use this for initialization
	void Start () {
        newPosition = this.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        //if(Input.GetKey(KeyCode.UpArrow)){
           // if (Input.GetKey(KeyCode.UpArrow)) { }
           // newPosition = newPosition + new Vector3(0, 0.1f, 0);
           // this.transform.position = newPosition;}
        //Input.GetAxis("Vertical");
        newPosition.z += (Input.GetAxis("Vertical")* movementSpeed* Time.deltaTime);
        this.transform.position = newPosition;

        newPosition.x += (Input.GetAxis("Horizontal") * movementSpeed * Time.deltaTime);
        this.transform.position = newPosition;
        }
}
